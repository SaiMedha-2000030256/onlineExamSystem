from django.apps import AppConfig


class ProfConfig(AppConfig):
    name = 'prof'
